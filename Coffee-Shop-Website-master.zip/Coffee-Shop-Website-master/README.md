# IMPORTANT

Do not put real info into this website.
I do not sell anything or make any profit from this project.

# Coffee-Shop-Website

Want to view the project? Click on the link.
Hosted by GitHub: https://lchua2314.github.io/Coffee-Shop-Website/dist/index.html

# References

All coffee products and information taken from Starbucks.com
I do not own anything and do not sell any actual coffee.

favicon.png: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.perfectespresso.ro%2Fthemes%2FCoffee%2Fimages%2Ffavicon%2F&psig=AOvVaw19Fuf2gKPKzOOAKhmudLVh&ust=1595237706040000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCJjUhNuB2eoCFQAAAAAdAAAAABAn

home-bg.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.cancer.org%2Flatest-news%2Fcoffee-and-cancer-what-the-research-really-shows.html&psig=AOvVaw0iq9EtfvX1hadGn03z2syZ&ust=1590973260774000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCOD5pLPz3OkCFQAAAAAdAAAAABBA

sign-up-bg.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwallpaperscraft.com%2Fdownload%2Fcoffee_table_cup_glasses_119666%2F1920x1080&psig=AOvVaw2MA_pcegEkfrvZx3UBEzQB&ust=1590974822660000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCKCc1aL53OkCFQAAAAAdAAAAABBp

menu-bg.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.besthdwallpaper.com%2Ffood-and-drink%2Fcoffee-with-chocolate-dt_en-US-3687.html&psig=AOvVaw2MA_pcegEkfrvZx3UBEzQB&ust=1590974822660000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCKCc1aL53OkCFQAAAAAdAAAAABBi

menu.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.traderjoes.com%2Fdigin%2Fpost%2Fbarista-espresso-coffee-blend&psig=AOvVaw1Q_nyaUFrvBSr4kv2wykRg&ust=1591140285879000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCMi9t9nh4ekCFQAAAAAdAAAAABAg

who-we-are.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fnudatasecurity.com%2Fresources%2Fblog%2Flearning-about-online-security-from-your-barista%2F&psig=AOvVaw1Q_nyaUFrvBSr4kv2wykRg&ust=1591140285879000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCMi9t9nh4ekCFQAAAAAdAAAAABBJ

services.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.goodasgold.com%2Fcoffee%2Four-coffee-services%2F&psig=AOvVaw2za9K_MQKkR1ToKG8xl_zF&ust=1591140760043000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCIj08LPj4ekCFQAAAAAdAAAAABAP

caffe-americano.webp, caffe-misto.webp, dark-roast-coffee.webp, cappuccino.webp, espresso.webp, espresso-macchiato.webp, flat-white.webp: All found on https://www.starbucks.com/menu/drinks/hot-coffees (NOTE: All of these were converted to jpg)

entertainment.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Flaslomaspage.org%2F2019%2F05%2F31%2Fopen-mic-at-coffee-shop%2F&psig=AOvVaw1DUXu5PgKXYyURlre7axMt&ust=1591665273617000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCNib4L2H8ekCFQAAAAAdAAAAABAD

parking.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fnypost.com%2F2022%2F03%2F17%2Falternate-side-parking-suspended-in-nyc-over-coronavirus%2F&psig=AOvVaw1BmUY4leyjAhUozY0nLHtp&ust=1591665646528000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCLiF8eOG8ekCFQAAAAAdAAAAABAb

venue.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.keurig.ca%2Fblog%2Fhow-to-host-an-afternoon-coffee-party%2F&psig=AOvVaw3nq5zVpaTUvJL8P4GuEXem&ust=1591667832936000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCJjKsfGO8ekCFQAAAAAdAAAAABAD

services-bg.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.tastingtable.com%2Fdrinks%2Fnational%2Fcompass-coffee-marines-dc-shaw&psig=AOvVaw2vVbocM3H31LuCfO5w7T3x&ust=1591666628699000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCIj5krSK8ekCFQAAAAAdAAAAABAJ

contact-bg.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.theinfatuation.com%2Fnew-york%2Fguides%2Fcoffee-shops-nyc-for-doing-work&psig=AOvVaw1gbHAmEzhlhfm5U_O7eB4f&ust=1591748046685000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCPCl-du58-kCFQAAAAAdAAAAABAw

sign-in-bg.jpg: https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.health.harvard.edu%2Fblog%2Fhealth-benefits-of-coffee-and-a-proposed-warning-label-2018072514319&psig=AOvVaw1tnoweTxuXsPkwotPoD1GS&ust=1591919422302000&source=images&cd=vfe&ved=0CAMQjB1qFwoTCJDr9pK4-OkCFQAAAAAdAAAAABAr
